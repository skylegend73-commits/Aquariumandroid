AQUARIUM ANDROID - BUILD DARI TELEFON

Projek ini ialah versi awal game aquarium: ikan bergerak, Feed, Clean dan Shop.

Cara paling mudah tanpa PC:
1. Buat akaun GitHub di github.com menggunakan telefon.
2. Buat repository baru bernama AquariumAndroid.
3. Upload semua fail/folder dalam ZIP ini ke repository.
4. Buka tab Actions -> Build Aquarium APK -> Run workflow.
5. Tunggu sehingga selesai.
6. Buka run yang berjaya -> Artifacts -> Aquarium-debug-apk.
7. Download ZIP artifact dan buka app-debug.apk untuk install.

Jika GitHub minta kebenaran Actions, benarkan Actions untuk repository tersebut.

Nota: APK debug ini ialah prototype yang boleh dimainkan. Game boleh dikembangkan lagi dengan 20 ikan, dekorasi, level, misi, save game dan grafik yang lebih cantik.
