package com.example.aquarium;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    AquariumView tank;
    TextView coins, level, status;
    int coinCount = 500, xp = 0, lv = 1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(0,105,148));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(18,10,18,10); top.setBackgroundColor(Color.rgb(0,105,148));
        level = label("LV 1", Color.WHITE, 18); coins = label("🪙 500", Color.WHITE, 18);
        top.addView(level,new LinearLayout.LayoutParams(0,58,1)); top.addView(coins,new LinearLayout.LayoutParams(-2,58));
        root.addView(top);
        tank = new AquariumView(); root.addView(tank,new LinearLayout.LayoutParams(-1,0,1));
        status = label("Selamat datang! Beri makan ikan anda 🐟", Color.DKGRAY, 15); status.setGravity(Gravity.CENTER); status.setPadding(8,6,8,6); root.addView(status,new LinearLayout.LayoutParams(-1,42));
        LinearLayout buttons = new LinearLayout(this); buttons.setPadding(8,4,8,8);
        addButton(buttons,"🍽 Feed",v->feed()); addButton(buttons,"🧽 Clean",v->clean()); addButton(buttons,"🐠 Shop",v->shop());
        root.addView(buttons,new LinearLayout.LayoutParams(-1,60)); setContentView(root);
    }
    TextView label(String s,int c,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    void addButton(LinearLayout p,String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);p.addView(b,new LinearLayout.LayoutParams(0,-1,1));}
    void feed(){coinCount+=10; xp+=10; if(xp>=100){xp=0;lv++;} coins.setText("🪙 "+coinCount);level.setText("LV "+lv);status.setText("Ikan makan dengan gembira! +10 🪙  +10 XP");tank.happy=100;tank.invalidate();}
    void clean(){status.setText("Aquarium bersih! Happiness +10 ✨");tank.happy=Math.min(100,tank.happy+10);tank.invalidate();}
    void shop(){if(coinCount>=100){coinCount-=100;tank.addFish();coins.setText("🪙 "+coinCount);status.setText("Ikan baru masuk aquarium! 🐠");}else status.setText("Syiling tak cukup.");}

    class Fish {float x,y,vx,vy;int type;Fish(int t,float xx,float yy){type=t;x=xx;y=yy;vx=(float)(1.2+Math.random()*2.2)*(Math.random()<.5?-1:1);vy=(float)(Math.random()-.5)*.8f;}}
    class AquariumView extends View {
        Paint p=new Paint(3); ArrayList<Fish> fish=new ArrayList<>(); Random r=new Random(); int happy=85;
        AquariumView(){super(MainActivity.this); fish.add(new Fish(0,160,180));fish.add(new Fish(1,420,260));fish.add(new Fish(2,280,360));setBackgroundColor(Color.rgb(20,150,205));}
        void addFish(){fish.add(new Fish(fish.size()%3,100+r.nextInt(Math.max(1,getWidth()-200)),100+r.nextInt(300)));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();
            p.setColor(Color.rgb(7,104,160));c.drawRect(0,0,w,h,p);p.setColor(Color.rgb(238,205,140));c.drawRect(0,h-70,w,h,p);
            p.setColor(Color.rgb(30,130,70));for(int x=30;x<w;x+=95){c.drawRect(x,h-110,x+8,h-70,p);c.drawOval(x-18,h-135,x+28,h-92,p);}
            p.setColor(Color.WHITE);p.setTextSize(16);c.drawText("Happiness: "+happy+"%",18,28,p);
            for(int i=0;i<8;i++){float bx=45+i*73, by=(h-100)-((System.currentTimeMillis()/25+i*80)%(h-150));p.setColor(0x6688EEFF);c.drawCircle(bx,by,4,p);}
            for(Fish f:fish){f.x+=f.vx;f.y+=f.vy;if(f.x<45||f.x>w-45)f.vx*=-1;if(f.y<70||f.y>h-105)f.vy*=-1;drawFish(c,f);}
            postInvalidateDelayed(30);
        }
        void drawFish(Canvas c,Fish f){int col=f.type==0?Color.rgb(255,166,45):f.type==1?Color.rgb(245,75,60):Color.rgb(30,235,220);p.setColor(col);float dir=f.vx>=0?1:-1;RectF body=new RectF(f.x-32,f.y-18,f.x+32,f.y+18);c.drawOval(body,p);Path tail=new Path();tail.moveTo(f.x-30*dir,f.y);tail.lineTo(f.x-52*dir,f.y-22);tail.lineTo(f.x-52*dir,f.y+22);tail.close();c.drawPath(tail,p);p.setColor(Color.WHITE);c.drawCircle(f.x+20*dir,f.y-6,6,p);p.setColor(Color.BLACK);c.drawCircle(f.x+22*dir,f.y-6,3,p);p.setColor(0x55FFFFFF);c.drawCircle(f.x+5,f.y-10,5,p);}
    }
}
